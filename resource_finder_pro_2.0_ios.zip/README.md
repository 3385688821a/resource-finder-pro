# Resource Finder MVP

中文优先、支持英文和日文界面的全网资源搜索 MVP。

## 功能
- DuckDuckGo 网页搜索（通过后端请求）
- 软件、学习、设计、AI、视频等分类关键词
- 普通搜索与 AI 摘要模式
- 中/英/日界面切换、深色模式、移动端适配

## 本地运行
需要 Python 3.10+。

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS / Linux:
source .venv/bin/activate

pip install -r requirements.txt
uvicorn app:app --reload
```

浏览器打开 http://127.0.0.1:8000

## 启用 AI 摘要
复制 `.env.example` 为 `.env`，设置 `OPENAI_API_KEY`。然后在启动服务前导出环境变量：
- macOS/Linux: `export OPENAI_API_KEY="你的密钥"`
- PowerShell: `$env:OPENAI_API_KEY="你的密钥"`

可选设置 `OPENAI_MODEL`。默认模型名为 `gpt-5`；请替换为你的 API 账户可用模型。

## 说明与限制
- 本项目是可运行的 MVP，不是完整的生产级全网爬虫或索引系统。
- 普通搜索依赖 DuckDuckGo HTML 页面，可能因地区、频率限制或页面变化而暂时失败。
- AI 模式目前对网页搜索结果进行摘要，不会绕过付费墙、登录限制或网站访问控制。
- 搜索结果版权归原网站所有；下载、抓取和再分发前请确认授权。
- 上线前应增加速率限制、缓存、日志、输入校验、隐私政策及搜索供应商合规审查。
