import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.resourcefinder.app',
  appName: '资源搜索',
  webDir: 'www',
  // 必须替换为已部署的 HTTPS 域名
  server: {
    url: 'https://YOUR-RESOURCE-FINDER-DOMAIN.example',
    cleartext: false,
    allowNavigation: ['YOUR-RESOURCE-FINDER-DOMAIN.example']
  },
  ios: { contentInset: 'automatic', preferredContentMode: 'mobile' }
};
export default config;
