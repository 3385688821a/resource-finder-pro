import os, concurrent.futures, urllib.parse
import requests
from bs4 import BeautifulSoup
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel

app = FastAPI(title="Resource Finder Pro")
app.mount("/static", StaticFiles(directory="static"), name="static")
HEADERS={"User-Agent":"Mozilla/5.0 (compatible; ResourceFinder/2.0)"}

class SearchRequest(BaseModel):
    q: str
    lang: str = "zh"
    mode: str = "web"
    category: str = "all"
    engine: str = "all"
    safe: bool = True

@app.get("/")
def home():
    return FileResponse("static/index.html")

def ddg(q, limit=12):
    r=requests.get("https://html.duckduckgo.com/html/",params={"q":q},headers=HEADERS,timeout=15)
    r.raise_for_status()
    soup=BeautifulSoup(r.text,"html.parser"); out=[]
    for x in soup.select(".result"):
        a=x.select_one(".result__a"); s=x.select_one(".result__snippet")
        if a:
            url=a.get("href","")
            if url.startswith("//"): url="https:"+url
            out.append({"title":a.get_text(" ",strip=True),"url":url,"snippet":s.get_text(" ",strip=True) if s else "","engine":"DuckDuckGo"})
        if len(out)>=limit: break
    return out

def bing_rss(q, limit=12):
    url="https://www.bing.com/search?format=rss&q="+urllib.parse.quote(q)
    r=requests.get(url,headers=HEADERS,timeout=15); r.raise_for_status()
    soup=BeautifulSoup(r.text,"xml"); out=[]
    for item in soup.find_all("item")[:limit]:
        out.append({"title":item.title.get_text(" ",strip=True) if item.title else "",
                    "url":item.link.get_text(" ",strip=True) if item.link else "",
                    "snippet":item.description.get_text(" ",strip=True) if item.description else "",
                    "engine":"Bing"})
    return out

def brave_api(q, limit=12):
    key=os.getenv("BRAVE_SEARCH_API_KEY")
    if not key: return []
    r=requests.get("https://api.search.brave.com/res/v1/web/search",
      params={"q":q,"count":limit},headers={"X-Subscription-Token":key,"Accept":"application/json"},timeout=15)
    r.raise_for_status()
    data=r.json().get("web",{}).get("results",[])
    return [{"title":x.get("title",""),"url":x.get("url",""),"snippet":x.get("description",""),"engine":"Brave"} for x in data]

@app.post("/api/search")
def search(req: SearchRequest):
    q=req.q.strip()
    if not q: return {"results":[],"summary":""}
    terms={"software":" software apps tools","learning":" tutorials courses documentation","design":" design assets images fonts","ai":" AI tools","video":" videos"}
    query=q+terms.get(req.category,"")
    providers={"ddg": [ddg],"bing":[bing_rss],"brave":[brave_api],"all":[ddg,bing_rss,brave_api]}
    selected=providers.get(req.engine,providers["all"])
    results=[]; errors=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        futures=[pool.submit(fn,query,10) for fn in selected]
        for f in concurrent.futures.as_completed(futures):
            try: results.extend(f.result())
            except Exception as e: errors.append(str(e))
    seen=set(); unique=[]
    for x in results:
        u=x.get("url","")
        if not u or u in seen: continue
        seen.add(u); unique.append(x)
    unique=unique[:24]
    summary=""
    if req.mode=="ai":
        key=os.getenv("OPENAI_API_KEY")
        if key and unique:
            try:
                from openai import OpenAI
                client=OpenAI(api_key=key)
                context="\n".join(f"{i+1}. {x['title']} — {x['snippet']} [{x['url']}]" for i,x in enumerate(unique[:12]))
                prompt=f"用户搜索：{q}\n网页搜索结果：\n{context}\n用用户选择的语言（{req.lang}）总结相关结果，区分事实与推测，不要编造。指出值得优先查看的结果。"
                response=client.responses.create(model=os.getenv("OPENAI_MODEL","gpt-5"),input=prompt)
                summary=response.output_text
            except Exception: summary="AI 摘要服务暂时不可用，以下仍显示聚合网页结果。"
        else: summary="AI 摘要尚未启用：请配置 OPENAI_API_KEY。当前已聚合可用搜索引擎结果。"
    return {"results":unique,"summary":summary,"providers":list(dict.fromkeys(x["engine"] for x in unique)),
            "notice":"搜索结果来自第三方搜索服务；部分引擎可能因地区、网络或限流而不可用。","errors":errors[:2] if not unique else []}
