# Resource Finder Pro 2.0 + iOS 自签名工程

## 本次升级
- 手机优先响应式布局，支持 iPhone / Android 浏览器与平板、PC。
- 搜索后端聚合 DuckDuckGo、Bing RSS；可选 Brave Search API。
- 结果去重、来源标识、分类检索、中文/英文/日文界面。
- AI 摘要通过 OpenAI API 启用。
- 附带 Capacitor iOS 壳工程，可在 Mac/Xcode 构建签名 IPA。

## 一、运行 Web 服务
Python 3.10+：
```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8000
```
生产环境请部署到 HTTPS 域名。示例环境变量见 `.env.example`。Brave 搜索需要 `BRAVE_SEARCH_API_KEY`；AI 摘要需要 `OPENAI_API_KEY`。未配置 Brave 时仍可使用 DuckDuckGo + Bing（视网络可用性）。

## 二、iOS IPA 构建（需要 Mac）
**不能在此项目包内直接生成可安装的 IPA**：iOS 必须由 Xcode 使用你的 Apple 签名身份和 provisioning profile 签名。项目已提供 Capacitor 外壳。

1. 先把 Web 服务部署到 HTTPS 公网域名。
2. 编辑 `ios-wrapper/capacitor.config.ts`，将 `server.url` 和 `allowNavigation` 中的示例域名换成真实域名。
3. Mac 安装 Xcode、Node.js。
4. 执行：
```bash
cd ios-wrapper
npm install
npx cap add ios
npx cap sync ios
npx cap open ios
```
5. Xcode 选择 App target → Signing & Capabilities：
   - 勾选 Automatically manage signing
   - Team 选择你的 Apple ID / Personal Team
   - Bundle Identifier 使用 `com.resourcefinder.app`（如冲突，改成你自己的唯一 ID）
6. 连接 iPhone，选择设备，点击 Run 完成个人开发者签名安装。
7. 如需 IPA：Xcode → Product → Archive → Organizer → Distribute App。根据你的 Apple 账户类型选择可用的导出方式。

## 三、关于“自签”
- 个人免费 Apple ID / Personal Team 通常有安装数量、签名有效期和设备限制；重签或重新安装可能需要周期性操作。
- 付费 Apple Developer Program 可以使用更完整的开发/Ad Hoc 分发能力，但仍需正确的证书、设备注册和描述文件。
- AltStore、SideStore、Sideloadly 等侧载工具也需要由用户自己的 Apple ID/证书签名；它们不能绕过 Apple 的签名机制。
- 不要把 Apple ID 密码、私钥或证书发给第三方。建议在自己的 Mac 上签名。
- 我没有你的 Apple 签名证书、描述文件或 Mac/Xcode 环境，因此本交付是可构建的 iOS 工程，不是已经签名的 IPA 文件。

## 搜索引擎说明
手机端通过你的后端访问搜索供应商，使用的是桌面级网页搜索结果接口/服务，而不是把 Google/Bing PC 页面强行塞进手机。Bing RSS 与 DuckDuckGo HTML 可能随服务策略变化而限流或调整；商业部署建议使用有正式 API 授权的搜索服务，并遵守其条款。不要绕过登录、付费墙、验证码或访问限制。
